package com.example.kickevent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KickeventApplicationTests {

	@Test
	void contextLoads() {
	}

}
